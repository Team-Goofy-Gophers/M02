```markdown
## HACKFEST - 2025

**Team Name:** Spicy Marshmallows
**College Name:** Cambridge Institute Of Technology, Karnataka
**Track:** Open Innovation
**Problem Statement:** Authentication methods such as passwords, PINs, and fingerprints are exposed to security issues, users often struggle with remembering passwords instead we use an individuals HEARTBEAT as an unique authenticator which is nearly impossible to replicate.

**Technology Stack:**
*   Frontend: Flutter (Cross-platform mobile app)
*   Backend: Python (Flask for API services)
*   Database: Firebase / PostgreSQL (For user authentication data storage)
*   ML Model: TensorFlow (For heartbeat pattern recognition)
*   Hosting: Firebase Cloud Functions / AWS

**Approach:** PulsePass leverages unique ECG signals for biometric authentication, ensuring secure access to sensitive applications without traditional passwords. The app captures the user's heartbeat signature and verifies it against stored patterns, enhancing security and reducing fraud risks.

**Use Cases:**
*   Secure Login for Banking & Healthcare Apps – Prevents unauthorized access.
*   Two-Factor Authentication Alternative – Eliminates reliance on OTPs and passwords.
*   Workplace & Personal Device Security – Unlocks devices using heartbeat recognition.

**Architecture:**

**System Components:**
*   Flutter App (User Interface) – Captures heartbeat data and sends it for verification.
*   Backend Server (Flask) – Processes authentication requests and manages heartbeat data.
*   Database – Stores user profiles and heartbeat patterns.
*   Machine Learning Model – Analyzes and authenticates unique heartbeat signals.
*   Cloud Hosting – Ensures scalability and remote access

**Additional Information:**
*   **Security & Privacy:**
    *   Encrypted heartbeat data for enhanced privacy.
    *   GDPR-compliant data handling.
    *   Works even without internet by storing locally encrypted models.
*   **Future Scope:**
    *   Integrating AI for adaptive authentication.
    *   Expanding to smartwatch and wearable authentication.
    *   Collaboration with healthcare institutions for medical applications.
```