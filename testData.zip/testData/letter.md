```markdown
A Omkar G Prabhu

Co-Head, Technical Committee

Incridea ‘25

15 January 2025

Dr. Niranjan N Chiplunkar

The Principal

NMAMIT, Nitte

Dr. Narasimha Bailkeri
```

---

[Your Name/Incridea 2025 Organizing Committee]
[Your Contact Information]

A Omkar G Prabhu

Recommended and Forwarded

Dr. Shashank Shetty

Faculty In-Charge

Technical Committee, Incridea ’25