```markdown
GEMINI_API_KEY = "[MASKED]"
```