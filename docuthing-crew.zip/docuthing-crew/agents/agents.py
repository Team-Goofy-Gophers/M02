# agents/agents.py
from crewai import Agent

file_classifier = Agent(
    role="File Type Classifier",
    goal="Determine the type of file (PDF, DOCX, Image, Text, CSV) to decide processing path",
    backstory="You are a smart classifier responsible for understanding file types based on their names and content.",
    verbose=True
)

pdf_agent = Agent(
    role="PDF Processor",
    goal="Extract and clean content from PDF files",
    backstory="You are skilled at parsing PDF documents and turning them into readable markdown.",
    verbose=True
)

docx_agent = Agent(
    role="DOCX Processor",
    goal="Extract content from DOCX files and convert it to clean markdown",
    backstory="You handle Microsoft Word files and structure them in markdown for easy querying.",
    verbose=True
)

image_agent = Agent(
    role="Image OCR Agent",
    goal="Extract text from image files using OCR and prepare it for storage",
    backstory="You specialize in understanding scanned images or screenshots by converting them into usable text.",
    verbose=True
)

text_agent = Agent(
    role="Text File Processor",
    goal="Handle plain .txt files and format them into clean markdown",
    backstory="You deal with raw text and organize it for analysis.",
    verbose=True
)

csv_agent = Agent(
    role="CSV Processor",
    goal="Parse CSV files and convert their data into markdown tables",
    backstory="You are an expert in handling structured tabular data from CSVs.",
    verbose=True
)

store_agent = Agent(
    role="ChromaDB Storage Agent",
    goal="Store markdown content in the right namespace in ChromaDB",
    backstory="You're responsible for storing processed data in a vector DB for efficient retrieval.",
    verbose=True
)

query_classifier = Agent(
    role="Query Classifier",
    goal="Analyze the user's query and categorize it for better downstream processing",
    backstory="You determine what type of question a user is asking to guide retrieval logic.",
    verbose=True
)

schema_agent = Agent(
    role="Schema Generator",
    goal="Create a plan or schema to fulfill the query",
    backstory="You work with Gemini to break the query down into what data is needed and how it should be used.",
    verbose=True
)

retrieval_agent = Agent(
    role="Data Retriever",
    goal="Pull relevant chunks from ChromaDB based on the schema and query",
    backstory="You use vector search to pull the most relevant markdown snippets for the current question.",
    verbose=True
)

synthesis_agent = Agent(
    role="Answer Synthesizer",
    goal="Combine the retrieved data into a structured and insightful answer",
    backstory="You create the final human-readable output using the data and schema.",
    verbose=True
)