# utils/chromadb_utils.py
import chromadb
from chromadb.config import Settings
from chromadb.utils.embedding_functions import GoogleGenerativeAiEmbeddingFunction
import os

CHROMA_DIR = os.getenv("CHROMA_DIR", "./chroma")
GOOGLE_API_KEY = os.getenv("GEMINI_API_KEY")

embedding_fn = GoogleGenerativeAiEmbeddingFunction(api_key=GOOGLE_API_KEY)


def get_chroma_client():
    return chromadb.Client(Settings(persist_directory=CHROMA_DIR))


def store_markdown(chat_id: str, doc_id: str, markdown_text: str):
    client = get_chroma_client()
    collection = client.get_or_create_collection(name=chat_id, embedding_function=embedding_fn)
    collection.add(
        documents=[markdown_text],
        ids=[doc_id],
        metadatas=[{"source": doc_id}]
    )
    client.persist()


def retrieve_markdown_chunks(chat_id: str, query: str, n_results: int = 5):
    client = get_chroma_client()
    collection = client.get_collection(name=chat_id, embedding_function=embedding_fn)
    results = collection.query(query_texts=[query], n_results=n_results)
    return results.get("documents", [[]])[0]
