from crewai import Task
from agents import query_classifier, schema_agent, retrieval_agent, synthesis_agent

# Input: query string and chat_id for context filtering
def create_query_tasks(query: str, chat_id: str):
    classify_task = Task(
        description=f"Classify the query: '{query}'",
        expected_output="Type of query (e.g., factual, comparative, summary, tabular, etc.)",
        agent=query_classifier,
        async_execution=False,
        context={"query": query, "chat_id": chat_id}
    )

    schema_task = Task(
        description=f"Generate a structured schema/plan for answering: '{query}'",
        expected_output="Schema outlining what info is needed and how to fetch/format it",
        agent=schema_agent,
        async_execution=False,
        context={"query": query, "chat_id": chat_id}
    )

    retrieval_task = Task(
        description=f"Retrieve relevant documents for: '{query}'",
        expected_output="Chunks of relevant markdown text from ChromaDB",
        agent=retrieval_agent,
        async_execution=False,
        context={"query": query, "chat_id": chat_id}
    )

    synthesis_task = Task(
        description=f"Synthesize answer to: '{query}'",
        expected_output="Final structured output/answer",
        agent=synthesis_agent,
        async_execution=False,
        context={"query": query, "chat_id": chat_id}
    )

    return [classify_task, schema_task, retrieval_task, synthesis_task]
