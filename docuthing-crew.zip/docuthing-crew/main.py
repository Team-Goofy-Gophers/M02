import os
import uuid
from pathlib import Path

from crew.main_crew import CrewFactory  # Updated import

# Dummy chat session ID (simulate per-user basis)
CHAT_ID = "chat_001"

# Folder paths
UPLOAD_DIR = "uploads"

def run_ingestion():
    factory = CrewFactory()
    for file in os.listdir(UPLOAD_DIR):
        file_path = os.path.join(UPLOAD_DIR, file)
        if os.path.isfile(file_path):
            print(f"\n📥 Ingesting: {file}")
            try:
                crew = factory.create_ingestion_crew(file_path, CHAT_ID)
                result = crew.run([{"file_path": file_path, "chat_id": CHAT_ID, "doc_id": str(uuid.uuid4())}])
                print("✅ Ingestion complete.")
            except Exception as e:
                print(f"❌ Ingestion failed: {e}")

def run_query():
    factory = CrewFactory()
    query = input("\n🧠 Ask a question: ")
    print("\n🔍 Processing your query...")
    try:
        crew = factory.create_query_crew(query, CHAT_ID)
        result = crew.run([{"query": query, "chat_id": CHAT_ID}])
        print("\n💡 Final Answer:\n", result)
    except Exception as e:
        print(f"❌ Query failed: {e}")

if __name__ == "__main__":
    os.makedirs(UPLOAD_DIR, exist_ok=True)

    print("""
    =========================================
       🧠 Autonomous Document Intelligence
    =========================================
    1. Ingest documents
    2. Query the knowledge base
    """)

    run_ingestion()
    run_query()